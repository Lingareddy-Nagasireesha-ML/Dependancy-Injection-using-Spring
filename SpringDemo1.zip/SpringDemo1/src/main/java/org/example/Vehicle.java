package org.example;
import org.springframework.stereotype.Component;


public interface Vehicle {
    void drive();

}
